mkdir -p tmp
sort tests/sample.txt > tmp/sorted2.txt
cat tmp/sorted2.txt
