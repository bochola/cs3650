mkdir -p tmp
sort -o tmp/sorted.txt tests/sample.txt
cat tmp/sorted.txt
