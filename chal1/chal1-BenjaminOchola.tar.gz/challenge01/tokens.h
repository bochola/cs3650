// tokens.h

#ifndef TOKENS_H
#define TOKENS_H

#include "svec.h"

//token functions

svec* tokenize(const char* line);

#endif
