long square(long x) {
    
    return x * x;
}    
