true&& 	echo dont 	need spaces |tr o   i|tr a o 
