
#include <stdio.h>
#include <string.h>

#include "hmalloc.h"
#include "tools.h"

int
main(int _ac, char* _av[])
{
    int* a = hmalloc(50);
    int* b = hmalloc(50);
    int* c = hmalloc(50);
    
    hprintstats();
    hfree(a);
    hprintstats();
    hfree(c);
    hprintstats();
    hfree(b);
    hprintstats();
    return 0;
}



